package com.markusborg.ui;

/**
 * @author  Markus Borg
 * @since   2015-07-30
 */
public interface GhostingFinishedListener {

    void notifyGhostingFinished();
}
